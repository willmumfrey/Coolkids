const express = require('express')
var mysql = require('mysql');
const app = express()



var pool = mysql.createPool({
	host	:'localhost',
	user	:'root',
	password:'root',
	database:'coolkids'
});

var path = require('path');

app.use(express.static(__dirname + '/Public')); // set the static files location /public/img will be /img for users


//Frontend route

app.get('/', function(req, res) {

   res.sendFile(path.resolve('Public/html.html'));
 
 })

app.get('/profs', function(req, res) {

   res.sendFile(path.resolve('Public/prof-table.html'));
 
 })

app.get('/class', function(req, res) {

   res.sendFile(path.resolve('Public/class-table.html'));
 
 })

///////////////////////////////////////////////////////




app.get('/coolkids-professor_classes', function(req,res){
	
	pool.getConnection(function(err,connection){
		//Use the connection
		connection.query('Select Professors.URL_img, Professors.Prefix,Professors.First_name,Professors.Last_name,Professors.Description_professor,Classes.Class_name,Majors.Major_name,Raw_rating,Votes From Professor_classes Inner Join Professors On Professor_id=Professors.ID Inner Join Majors On Major_id=Majors.ID Inner Join Classes On Class_id=Classes.ID;', function(error,results,fields){

			connection.release();

			if(!err){

				res.json(results);

			}

		});


	});

});

app.get('/coolkids-classes', function(req,res){
	
	pool.getConnection(function(err,connection){
		//Use the connection
		connection.query('Select Professors.Prefix,Professors.First_name,Professors.Last_name,Classes.Class_name,Classes.Description_class,Majors.Major_name,Raw_rating,Votes From Professor_classes Inner Join Professors On Professor_id=Professors.ID Inner Join Majors On Major_id=Majors.ID Inner Join Classes On Class_id=Classes.ID;', function(error,results,fields){

			connection.release();

			if(!err){

				res.json(results);

			}

		});


	});

});

app.post('/wills-second-route', function(req,res){
	console.log('hello world');
	res.send('hello world - this is the response');
});

// turn computer into server
app.listen(3000, () => console.log('Example app listening on port 3000!'))
