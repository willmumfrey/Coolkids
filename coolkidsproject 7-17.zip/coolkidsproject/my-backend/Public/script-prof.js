$(document).ready(function(){

getallprof()

});



function getallprof(ajax){
 $.ajax({
        method: "get",
        url: "/coolkids-professor_classes",
        dataType: 'json',
        headers: {
            'Content-Type':'application/json',
            'Access-Control-Allow-Headers':'*',
            'Access-Control-Allow-Origin':'*'
        },
        success: function(data){

        for (var i = 0; i<data.length; i++){

                var a = data[i].Raw_rating;
                var b = data[i].Votes;
                var c = a / b;
                

            if (data[i].URL_img == "NA"){
                data[i].URL_img = "prof-pics/blank.jpg";
            }
       
            var profcard = "<div class='row'>"
            +"<div class='col-sm-2'>"
            +"<div class='row'>"
            +"<div class='rating-prof'>"
            +"<div class='col-sm-1'>"
            +"<div class='rating-numb' style='float:right'>"
            +c
            +"</div>"
            +"</div>"
            +"<div class='col-sm-1'>"
            +"<div class='rating10'>"
            +"/5"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"

            +"<div class='prof-rating'>"
            +"</div>"
            +"</div>"
            +"<div class='col-sm-3'>"
            +"<div class='headshot'>"
            +"<img src="+data[i].URL_img+">"
            +"</img>"
            +"</div>"
            +"</div>"

            +"<div class='col-sm-6'>"
            +"<div class='professor-description'>"
            +"<div class='prof-name'>"
            +"<h1 id='profName'>"
            +"</h1>"
            +"<div class='prof-rating'>"
            +"<h2 id='profRating'>"
            +data[i].Prefix+data[i].First_name+data[i].Last_name
            +"</h2>"
            +"</div>"

            +"<div class='major-class'>"
            +"<div class='row'>"
            +"<div class='col-sm-6'>"
            +"<div class='row'>"
            +"<div class='col-sm-12'>"
            +"<h2>"
            +"School:"
            +"</h2>"
            +"<h3 id='profSchool'>"
            +"College of Business"
            +"</h3>"
            +"</div>"
            +"<div class='col-sm-6'>"
            +"<div class='prof-major'>"                                   
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"<div class='col-sm-6'>"
            +"<div class='row'>"
            +"<div class='col-sm-12'>"
            +"<h2>"
            +"Major:"
            +"</h2>"                       
            +"<h3 id='profMajor'>"
            + data[i].Major_name 
            +"</h3>"                         
            +"</div>"
            +"</div>"
            +"</div>"

            +"<div class='col-sm-12'>"
            +"<div class='row'>"
            +"<div class='col-sm-12'>"
            +"<h2>"
            +"Classes:"
            +"</h2>"                         
            +"<h4 id='profClasses'>"
            + data[i].Class_name 
            +"</h4>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
                            
            +"<h2>"
            +"About me"
            +"</h2>"
            +"<div class='prof-descrip'>" 
            + data[i].Description_professor                
            +"<p id='profDescrip' style='background: rgba(223, 153, 0, .5); padding:5px;''>"                 
            +"</p>"
            +"</div>"     
            +"</div>"
            +"</div>"
            +"</div>"     
            +"</div>";


        

             console.log(profcard);
                $('.prof-table').append(profcard);

            }
        },
            

        	

        
        error: function(xhr, status, error) { console.log("ERROR: ", error) }
    
    

    });
};


