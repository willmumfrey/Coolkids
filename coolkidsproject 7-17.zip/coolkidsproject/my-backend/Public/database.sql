CREATE TABLE Professors (
	ID int NOT NULL,
	Prefix varchar(10) NOT NULL,
	First_name varchar(100) NOT NULL,
	Last_name varchar(200) NOT NULL,
	Description_professor varchar(1000) NOT NULL,
	URL_img varchar(200) NOT NULL,
	Featured boolean NOT NULL,
	PRIMARY KEY (ID)
);

CREATE TABLE Majors (
	ID int NOT NULL,
	Major_name varchar(100) NOT NULL,
	Description_major varchar(2000) NOT NULL,
	PRIMARY KEY (ID)
);

CREATE TABLE Classes (
	ID int NOT NULL,
	Class_name varchar(100) NOT NULL,
	Description_class varchar(2000) NOT NULL,
	PRIMARY KEY (ID)
);

Create TABLE Professor_classes (
	Professor_id int NOT NULL,
	Class_id int NOT NULL,
	Major_id int NOT NULL,
	Raw_rating int NOT NULL,
	Votes int NOT NULL,
	PRIMARY KEY (Professor_id, Major_id, Class_id),
	FOREIGN KEY (Professor_id) REFERENCES Professors(ID),
	FOREIGN KEY (Major_id) REFERENCES Majors(ID),
	FOREIGN KEY	(Class_id) REFERENCES Classes(ID)
);

INSERT INTO Professors (
	ID,
	Prefix,
	First_name,
	Last_name,
	Description_professor,
	URL_img,
	Featured
)
VALUES (
	1,
	"Professor ",
	"Sarah ",
	"Thorrick ",
	"Visiting Assistant Professor of Accounting",
	"prof-pics/sarah-thorrick.jpg",
	"0"
),
(
	2,
	"Dr. ",
	"Jean ",
	"Meyer ",
	"Visiting Assistant Professor of Accounting",
	"prof-pics/jean-meyer.jpg",
	"0"
),
(
	3,
	"Dr. ",
	"Daphne ",
	"Main ",
	"Associate Professor of Accounting",
	"prof-pics/daphne-main.jpg",
	"1"
),
(
	4,
	"Professor ",
	"Alfred(Ted) ",
	"Stacey ",
	"CPA, Visiting Assisstant Professor of Tax Accounting, and Director in the Tax Department of Bourgeois Bennet.",
	"prof-pics/alfred-stacey.jpg",
	"0"
),
(
	5,
	"Dr. ",
	"Leo ",
	"Krasonzhon ",
	"Associate Professor of Economics",
	"prof-pics/leo-krasonzhon.jpg",
	"0"
),
(
	6,
	"Dr. ",
	"Walter ",
	"Block ",
	"Harold E. Wirth Eminent Scholar Endowed Chair in Ecoonmics",
	"prof-pics/walter-block.jpg",
	"0"
),
(
	7,
	"Dr. ",
	"John ",
	"Levendis ",
	"Associate Dean, Associate Professor of Ecoonmics, Dr. John V. Connor Professor in Ecoonmics and Finance.",
	"prof-pics/john-levendis.jpg",
	"1"
),
(
	8,
	"Dr. ",
	"William ",
	"Barnett II ",
	"Chase Distinguished Professor of International Business; Professor of Ecoonmics",
	"prof-pics/william-barnett.jpg",
	"0"
),
(
	9,
	"Professor ",
	"Michael ",
	"Spanbauer ",
	"Visiting Assisstant Professor of Ecoonmics",
	"prof-pics/michael-spanbauer.jpg",
	"0"
),
(
	10,
	"Professor ",
	"Jon ",
	"Atkinson ",
	"Director of the Center for Entrepreneurship and Community Development; Visiting Assistant Professor of Management",
	"prof-pics/jon-atkinson.jpg",
	"1"
),
(
	11,
	"Dr. ",
	"Selma ",
	"Izadi ",
	"Visiting Assistant Professor of Finance",
	"prof-pics/selma-izadi.jpg",
	"0"
),
(
	12,
	"Professor ",
	"Michael ",
	"Gibbs ",
	"CPA, Guest lecturer of Finance, and CFO of MSA Associates, Inc.",
	"NA",
	"0"
),
(
	13,
	"Dr. ",
	"Mehmet ",
	"Dicle ",
	"Stanford H. Rosenthal Professor in Risk, Insurance, and Entrepreneurship; Associate Professor of Finance",
	"prof-pics/mehmet-dicle.jpg",
	"1"
),
(
	14,
	"Professor ",
	"Kurt ",
	"Gerwitz ",
	"Visiting lecturer of Finance",
	"prof-pics/kurt-gerwitz.jpg",
	"0"
),
(
	15,
	"Professor ",
	"Thomas ",
	"McQuaid ",
	"Associate Professor in Business",
	"NA",
	"0"
),
(
	16,
	"Professor ",
	"Marwan ",
	"Kabbani ",
	"Lecturer in Business Administration ",
	"NA",
	"0"
),
(
	17,
	"Dr. ",
	"Felipe ",
	"Massa ",
	"Associate Professor of Management",
	"prof-pics/felipe-massa.jpg",
	"0"
),
(
	18,
	"Dr. ",
	"Kendra ",
	"Reed ",
	"Barry and Teresa LeBlanc Professor in Business Ethics; Professor of Management",
	"prof-pics/kendra-reed.jpg",
	"1"
),
(
	19,
	"Professor ",
	"Jan ",
	"Anderson ",
	"Visiting Assistant Professor of Management",
	"prof-pics/jan-anderson.jpg",
	"0"
),
(
	20,
	"Professor ",
	"Scott ",
	"Sowder ",
	"Lecturer in Management",
	"NA",
	"0"
),
(
	21,
	"Professor ",
	"Brian ",
	"Gueniot ",
	"Coordinator/Executive Mentor Program in the College of Business.",
	"prof-pics/brian-gueniot.jpg",
	"0"
),
(
	22,
	"Dr. ",
	"Michelle ",
	"Johnston ",
	"Professor of Management",
	"prof-pics/michelle-johnston.jpg",
	"0"
),
(
	23,
	"Dr. ",
	"Catherine ",
	"Lenihan ",
	"Bilingual Marketing and Finance Executive and Professor",
	"prof-pics/catherine-lenihan.jpg",
	"0"
),
(
	24,
	"Dr. ",
	"Todd ",
	"Bacile ",
	"Assistant Professor of Marketing; Clifton A. Morvant Distinguished Professor in Business",
	"prof-pics/todd-bacile.jpg",
	"1"
),
(
	25,
	"Dr. ",
	"Adam ",
	"Mills ",
	"Assistant Professor of Marketing",
	"prof-pics/adam-mills.jpg",
	"0"
),
(
	26,
	"Dr. ",
	"Sloane ",
	"Signal ",
	"Visiting Assisstant Professor in Educational Leadership",
	"prof-pics/sloane-signal.jpg",
	"0"
),
(
	27,
	"Professor ",
	"Nate ",
	"Straight ",
	"Director of Institutional Effectiveness",
	"prof-pics/nate-straight.jpg",
	"0"
),
(
	28,
	"Professor ",
	"Aris ",
	"Kyriakides ",
	"Adjunct Lecturer in Decision Science",
	"prof-pics/aris-kyriakides.jpg",
	"0"
),
(
	29,
	"Professor ",
	"Christopher ",
	"Screen ",
	"Visiting Assistant Professor of Business Law",
	"prof-pics/christopher-screen.jpg",
	"1"
),
(
	30,
	"Professor ",
	"Wayne ",
	"Del Corral ",
	"Visiting Professor of Business Administration",
	"NA",
	"0"
),
(
	31,
	"Professor ",
	"Toni ",
	"Mobley ",
	"Senior Vice President and Chief Services Officer, Audubon Nature Institute",
	"prof-pics/toni-mobley.jpg",
	"0"
),
(
	32,
	"Professor ",
	"Ashley ",
	"Francis ",
	"Director of Graduate Programs, Visiting Assistant Professor of Management",
	"prof-pics/ashley-francis.jpg",
	"0"
),
(
	33,
	"Professor ",
	"Bradley ",
	"Warshauer ",
	"Business Writing Specialist",
	"prof-pics/bradley-warshauer.jpg",
	"0"
),
(
	34,
	"Dr. ",
	"Frankie ",
	"Weinberg ",
	"Associate Professor of Management",
	"prof-pics/frankie-weinberg.jpg",
	"0"
),
(
	35,
	"Dr. ",
	"Nicholas ",
	"Capaldi ",
	"Legendre-Soulé Distinguished Chair in Business Ethics; Professor of Management",
	"prof-pics/nicholas-capaldi.jpg",
	"1"
),
(
	36,
	"Professor ",
	"Harry ",
	"Bruns ",
	"Guest Instructor and Retired Telecommunications Executive",
	"prof-pics/harry-bruns.jpg",
	"0"
),
(
	37,
	"Dr. ",
	"Richard ",
	"Peters ",
	"Lecturer in Management",
	"prof-pics/richard-peters.jpg",
	"0"
),
(
	38,
	"Dr. ",
	"Kathy ",
	"Barnett ",
	"Director of Portfolio; Internship Program Coordinator; Assistant Professor of Management",
	"prof-pics/kathy-barnett.jpg",
	"1"
);


INSERT INTO Majors (
	ID,
	Major_name,
	Description_major
)
VALUES (
	1,
	"Accounting",
	"Accounting or accountancy is the measurement, processing, and communication of financial information about economic entities such as businesses and corporations. "
	),
(
	3,
	"Economics",
	"Economics is the social science that studies the production, distribution, and consumption of goods and services."
),
(
	4,
	"Finance",
	"Finance is a field that is concerned with the allocation (investment) of assets and liabilities (known as elements of the balance statement) over space and time, often under conditions of risk or uncertainty. Finance can also be defined as the science of money management."
),
(
	5,
	"International Business",
	"International business refers to the trade of goods, services, technology, capital and/or knowledge at a global level. It involves cross-border transactions of goods and services between two or more countries. Transactions of economic resources include capital, skills, and people for the purpose of the international production of physical goods and services such as finance, banking, insurance, and construction. International business is also known as globalization."
),
(
	6,
	"Management",
	"Management (or managing) is the administration of an organization, whether it is a business, a not-for-profit organization, or government body. Management includes the activities of setting the strategy of an organization and coordinating the efforts of its employees (or of volunteers) to accomplish its objectives through the application of available resources, such as financial, natural, technological, and human resources."
),
(
	7,
	"Marketing",
	"Marketing is the study and management of exchange relationships. Marketing is used to create, keep and satisfy the customer. With the customer as the focus of its activities, it can be concluded that Marketing is one of the premier components of Business Management - the other being innovation."
),
(
	8,
	"Decision Science",
	"Decision Science (or Decision Theory) is the study of the reasoning underlying an agents choices."
),
(
	9,
	"Legal Studies",
	"Legal Studies or Jurisprudence is the theoretical study of law, principally by philosophers but, from the twentieth century, also by social scientists. Scholars of jurisprudence, also known as jurists or legal theorists, hope to obtain a deeper understanding of legal reasoning, legal systems, legal institutions, and the role of law in society."
),
(
	10,
	"Business Administration",
	"Business administration is management of a business. It includes all aspects of overseeing and supervising business operations and related fields which include accounting, finance and marketing."
),
(
	24,
	"Entrepreneurship",
	"Entrepreneurship is the process of designing, launching and running a new business, which is often initially a small business. The people who create these businesses are called entrepreneurs."
);

INSERT INTO Classes (
	ID,
	Class_name,
	Description_class
)
VALUES (
	1,
	"Principles of Financial Accounting",
	"This course is designed to introduce students to accounting in a way that demonstrates the importance of accounting to society and the relevance of accounting to their future careers.  The objective of the course is for students to understand the essential financial components of businesses and to realize that accounting information is imperative in the decision making process of investors, creditors, management, and others."
	),
(
	2,
	"Intermediate Accounting I",
	"This course is an introduction to accounting theory and principles underlying the financial statements. Emphasis is on financial statement presentation and disclosure for cash, receivables, inventories, and debt and equity investments in corporate securities. The statement of cash flow and revenue recognition issues are covered."
),
(
	3,
	"Intermediate Accounting II",
	"This course is a continuation of ACCT B305. Topics include plant and equipment, intangibles, current and long-term liabilities, deferred taxes, leases, stockholders equity, and earnings per share."	
),
(
	4,
	"Tax Accounting I",
	"This course examines the concepts and methods of determining federal income tax liability for individuals. Topics emphasized include personal deductions, capital gain and loss provisions, and accounting methods."	
),
(
	5,
	"Government and Nonprofit Accounting",
	"This course is designed to help students become aware of the vitality of government and not-for-profit accounting and of the intellectual challenges that are presented.  This course studies accounting, budgeting, fiscal processes, and the financial records of governmental agencies and non-profit organizations. Fund accounting is introduced and emphasized."
),
(
	6,
	"Strategic Cost Accounting",
	"This course emphasizes contemporary topics in strategic cost management through an understanding of the underlying concepts and fundamental techniques involved in cost accounting for manufacturing and service companies. Job-order, process, and standard costing are examined to support an understanding of just-in-time and activity based systems, continuous improvement, quality measurements, and the theory of constraints, among others. Emphasis is on how cost management systems, with their performance evaluation and reward systems, encourage efforts to achieve an organization’s strategic goals."	
),
(
	7,
	"Accounting Information Systems",
	"This course emphasizes the problems of integrating automatic data processing and accounting information systems. Problems inherent in the development of systems and modeling are also covered."	
),
(
	8,
	"Advanced Accounting",
	"This course is designed for students to study the accounting reporting principles and procedures used in a variety of multi-corporate entity activities including mergers, acquisitions, and complex business transactions including consolidations.  Partnership formation, operation and changes in membership as well as partnership liquidations are also covered."
),
(
	9,
	"Audit and Assurance Services",
	"This course is an introduction to auditing and assurance services in the public accounting profession. The course covers the auditing environment, the auditing process, and the application of auditing concepts to various types of audits, including financial, operational, and compliance."
),
(
	10,
	"Tax Accounting II",
	"This course covers concepts and methods of determining federal income tax liability for corporations, partnerships, estates, and trusts."
),
(
	11,
	"Principles of Microeconomics",
	"This course is an introduction to economic analysis: efficiency and equity; production and exchange; costs, supply, and demand; markets, organizations, and government; competition, cooperation, and coercion; and international trade."
),
(
	12,
	"Principles of Macroeconomics",
	"This course is an introduction to various theories of inflation and unemployment; economic growth; money, banking, and financial intermediation; interest rates; business cycles; exchange rates, trade balances, and the balance of payments; deficits and the national debt; monetary, fiscal, exchange rate, income, and regulatory policies; and national income, product, and international payments accounting."
),
(
	13,
	"Intermediate Microeconomics",
	"This course is an analysis of market and firm coordination; the theory of consumer behavior and demand; the theory of supply; competition; the pricing of goods and resources; and government policies."
),
(
	14,
	"Intermediate Macroeconomics",
	"This course considers various theories concerning the functioning of the macroeconomy: Classical and PreKeynesian, Keynesian and the Neoclassical Synthesis, Monetarism, Supply-Side, Fishers Debt-Deflation Theory, Post Keynesian including Minskys Financial Instability Hypothesis, and Austrian. Also covered briefly are Rational Expectations, Real Business Cycles, New Keynesianism, and Dynamic Stochastic General Equilibrium theories."
),
(
	15,
	"The Market Process",
	"This course serves as an introduction to subjectivist economics. Primary emphasis is on the Austrian School. Topics covered include history and methodology; the market process and intervention; capital and interest; money, credit, and the financial system; and business cycles."
),
(
	16,
	"Industrial Organization and Public Policy",
	"This class investigates the nature of firms and industries: Why firms exist and why firms have diverse organizational structures; why industry structures differ; competition and monopoly; firm behavior; transaction cost theory; and the effects of antitrust policy."
),
(
	17,
	"Financial Management",
	"This course introduces the analytic techniques commonly used for the financial management of business firms. Topics include analysis of financial statements, financial forecasting, asset valuation, capital budgeting, working capital management, and financial structure."
),
(
	18,
	"Analysis of Financial Systems",
	"This course examines common techniques for the analysis of financial statements. In addition to covering traditional analytic approaches, this course explores the relationship between the selection of accounting procedures and the quality of the resulting statements."
),
(
	19,
	"Financial Institutions",
	"This course examines the purpose and functions of financial markets and financial institutions, domestic and global. Emphasis is on asset/liability management. Cases may be used to foster an understanding of the problems and opportunities of different financial institutions. It is highly recommended that the student take FIN B300, Financial Management, first."
),
(
	20,
	"Investments",
	"This course analyzes different investment alternatives in a risk-return framework. Techniques for selection, timing, and diversification of investment choices are emphasized. Portfolio theory is also explained as the capstone element at the end of this course"
),
(
	21,
	"Advanced Financial Management",
	"This course examines the theory and practice of financial management through case analysis and readings. Topics considered include working capital management, capital budgeting, financial structure, and dividend policy."
),
(
	22,
	"Student Managed Investment Fund",
	"This course applies investment and portfolio concepts to the management of a $1,000,000+ securities portfolio funded by a gift to Loyola for the College of Business. The aim is a hands-on approach to learning and applying technical/fundamental financial analysis, risk/return evaluation, macro/micro market evaluation, and portfolio management."
),
(
	23,
	"Financial Derivatives",
	"This course provides undergraduate students with the knowledge and comprehension of financial derivative instruments by providing theory and practice. Future, forward, option and swap contracts are discussed in detail as they apply to stocks, interest rates, foreign exchange and commodities. For each type of derivative instrument, underlying risk exposure, pricing and trading are discussed. Different trading strategies using options are provided with actual market information. Special emphasis is on the actual usage of derivatives within real markets for hedging and speculating purposes."
),
(
	24,
	"Multinational Business Strategy",
	"This course is designed to enhance the student’s analytical, research, communication, and strategic skills via two methods–first, in-depth class discussions of concepts and cases focusing on the opportunities, challenges, and strategies pursued by large multinationals; second, an applied research project whereby students formulate and defend a global strategic plan for a company, after performing a strategic audit and assessing the forces and trends shaping the future of the industry in which it operates."
),
(
	25,
	"Management and Organization Behavior",
	"The course explores organizations as social units and the phenomena of individual and group behavior in organizations. Topics include evolution of research in organizational principles and practices; personality, perception, and attitude formation; motivation; behavior; performance; structure; groups; planning and decision making; communication; power and conflict; leadership; stress; and international issues."
),
(
	26,
	"Production and Operations Management",
	"This course deals with the decision making involved in selecting, designing, operating, and controlling activities of the operations system for continuous improvement. Topics include total quality management, forecasting, product design and process selection, capacity planning and location, facility layout, project planning and control, production planning, and just-in-time production and inventory management."
),
(
	27,
	"Project and Process Management",
	"This course introduces fundamental approaches for managing business operations in the fields of process and project management. Students will develop skills which will enable them to define, scope, schedule, and manage projects and associated tasks; to analyze processes to ensure quality and create value; and to manage the flow of information, products, and/or services across a network of customers, employees, and stakeholders. This course focuses on practical application through hands-on project leadership and case studies which will support students’ ability to analyze real world problems, identify possible solutions, and manage the appropriate changes to achieve organizational performance goals."
),
(
	28,
	"Management Information Systems",
	"This course introduces the significant uses of information technology in the business world. The student will study steps necessary to design, implement, and operate a computer-based information system. More significantly, the student will study the complex issues involved in managing information technology, including the rapidly changing issues involving the telecommunications industry."
),
(
	29,
	"Human Resource Management",
	"This course focuses on current issues in human resource management in both the private and public sectors. Topics include civil service systems, labor relations, manpower, planning, job analysis, recruitment, selection, training, appraisal, compensation, benefits, job evaluation, and personnel systems evaluation."
),
(
	30,
	"Psychology in Management",
	"This course presents the theories, experiments, and problem-solving efforts of the psychologist and the behavioral scientist in the area of administrative action. Topics include cognitive dissonance, reinforcement theory, need achievement, leadership, and attitude change."
),
(
	31,
	"Leadership and Team Building",
	"This course examines leadership as a process of influencing others toward the achievement of goals. The process functions through complex interactions among the leader, relevant followers, and shared situations. This course introduces students to current research and methodology relating to each of the three components of leadership, in the role of developing effective teamwork."
),
(
	32,
	"Basic Marketing",
	"This course assists students in understanding the role of marketing from a managerial perspective. It examines how product, pricing, promotion, and distribution decisions are made to satisfy the needs of specific target markets. The impacts of political-legal, competitive, socio-cultural, technological, and economic environments on marketing are also studied."
),
(
	33,
	"Electronic Marketing",
	"The course is designed to enable students to understand and gain experience using the Google Analytics platform. Google Analytics is a widely used web analytics software program. The course is designed to prepare students to pass the certification exam offered by Google. At the end of this course, top performing students will earn an individual certification from Google, which will make any student a highly desirable job candidate (i.e., a Google certified professional may have more job offers at a higher dollar amount compared to fellow students who have a four-year degree without this professional certification). To a lesser extent, the course may also discuss search engine marketing, paid search advertising, search engine optimization, online retailing, and social media marketing topics."
),
(
	34,
	"Promotions Management",
	"This course emphasizes development of integrated promotional programs. Advertising, public relations, personal selling, promotional packaging, along with many other sales stimulating methods and techniques are covered."
),
(
	35,
	"Advanced Marketing Strategy",
	"This course is an analysis of a wide variety of marketing problems. The case-situation method is employed, with emphasis on managerial problem solving amid real world constraints; and the use of behavioral and quantitative techniques."
),
(
	36,
	"Strategic Marketing",
	"NA"
),
(
	37,
	"Business Statistics",
	"This course is an introduction to the statistics used in business. Topics covered are sources and collection of business data, describing data, probability concepts, the use of confidence limits to estimate the mean or the proportion, the use of hypothesis tests, analysis of variance, and simple correlation and linear regression to discover how two variables are related to each other. The use of Microsoft Excel spreadsheet software is an integral part of this hands-on course."
),
(
	38,
	"Business Decision Modeling",
	"This course covers the development and interpretation of statistical, financial, and mathematical models for business decision making. Modeling techniques discussed may include applied probability distributions, time series analysis / forecasting, classification and/or clustering models, scenario / what-if analysis, linear optimization and sensitivity analysis, simulation models, decision trees / decision analysis, and expected value / utility analysis. Students gain expertise in the application of rigorous quantitative analysis to complex business decisions in the areas of strategic planning, financial management, and operations research."
),
(
	39,
	"Decision Support System",
	"This course covers the use and design of the information, knowledge / intelligence, and technological resources that are employed by managerial decision makers to gain a better understanding of a business and its customers. “Decision support systems” refers to the “front-end” technology that is generally associated with a data warehouse, and which provides modeling and analysis capabilities to help key decision makers evaluate ways in which to improve business operations and reach organizational goals. This course covers general topics related to the design of such systems, as well as practical issues of implementation of Enterprise Resource Planning (ERP), Customer Relationship Management (CRM), “dashboard” analytics, or other business applications. Data security and ethics are also considered."
),
(
	40,
	"Contemporary Managerial Decision Making",
	"This course prepares students to be effective decision-makers by providing diagnostic and analytical tools / skills for informing effective decisions. A course project requires students to use (1) diagnostic skills to formulate problems, (2) decision-modeling skills to frame and manage results and risk, (3) data collection skills to obtain appropriate information, (4) data analysis skills to draw conclusions, (5) oral and written communication skills to explain why/how the problem can be solved, and (6) managerial skills such as planning, organizing, leading, and controlling to show how the solution can be deployed."
),
(
	41,
	"Business Law for Accounting",
	"This course covers private commercial transactions as relevant to accounting, including contracts, sales, and property. Commercial paper, agency, partnerships, and corporation law are also included."
),
(
	42,
	"Legal Environment of Business",
	"This course is an introductory course covering the nature and operation of the U.S. legal system, constitutional law affecting commerce, employment discrimination law, and environmental protection law."
),
(
	43,
	"Introduction to Business",
	"The course introduces the nature of business and its complexities in the context of the environment in which it operates. Subjects covered include ownership forms, organization, management, marketing, accounting, financial institutions, labor relations, basic word processing, e-mail, spreadsheets, data base, library resources, and small businesses."
),
(
	44,
	"Business Communication",
	"This course serves to improve the students ability to create successful communication products–both written and oral. Topics include the process for successful communication, team communication business writing, report writing using style guidelines, online communication, and presentation skills."
),
(
	45,
	"Business Ethics",
	"This course examines the sources of societal pressure, business reaction, and the community’s expectation. The entire spectrum of corporate and government activities are discussed against the framework of the demands made on the firm and government by forces outside of the marketplace."
),
(
	46,
	"Business Policy",
	"This course provides students with the opportunity to integrate the skills acquired in prior coursework in analyzing the internal and external environments of organizations and has students learn how to formulate and implement strategies that will allow a firm to compete successfully within its environment."
),
(
	632,
	"International Accounting",
	"This course covers topics including comparison of accounting between US GAAP and IFRS; examination of common financial, managerial, and tax accounting issues faced by U.S. multinational firms, including the impact of transactions conducted in foreign currencies; defenses against currency rate changes such as forward exchange forward contracts; and the restatement of foreign currency financial statements for overseas subsidiaries."
),
(
	633,
	"International Economics",
	"This course considers exchange rate systems; international monetary arrangements; adjustments in international disequilibrium situations; relationships among rates of exchange, inflation, interest, and unemployment; and domestic and international economic policies. It also considers various theories of competitive advantage in international trade, the nature and effects of commercial policies, and international economic integration."
),
(
	634,
	"Econometrics I- Linear",
	"This is an intermediate level statistics course. After a brief overview of statistics, the course covers least squares estimation, statistical inference, diagnostic methods, selection and evaluation of functional form, and simultaneous equations estimation. The course focuses more on applied work than on its theoretical underpinnings. Students are actively involved with computer exercises in this course, using the STATA software program. Students will complete a comprehensive statistical research project."
),
(
	635,
	"Econometrics II- Time Series",
	"This course is an advanced level statistics course focusing on time-series models. The course covers how to detect, estimate, and make valid inferences from univariate, multivariate, and potentially panel data. Classic univariate models may include autoregressive, moving average, integrated, and distributed lag models; multivariate models may include vector autoregressions and cointegrated models; panel-data models include panel-VARs. The course focuses more on applied work than on its theoretical underpinnings. Students are actively involved with computer exercises in this course, using the STATA software program. Students will complete a comprehensive statistical research project."
),
(
	636,
	"Entrepreneurial Finance",
	"This course follows the financial decisions over the of the life cycle of an entrepreneurial venture from the creation of the business through raising capital, managing for growth, and exit through acquisition or IPO."
),
(
	637,
	"International Financial Management",
	"This course explores the problems and complexities associated with trade and investments that take place across national boundaries. Topics include financing international trade, exchange rate risk, risk exposure and management, and direct and indirect international investment considerations."
),
(
	638,
	"International Management",
	"This course explores the complexities arising from managing an international business with a framework for analyzing and successfully operating across nations. Students develop interpersonal and cross-cultural understanding and negotiation skills through in-class participatory exercises, case discussions, supplementary readings, and a group research project."
),
(
	639,
	"Import/Export Operations",
	"This course covers the basics of international trade, transaction sequencing, transportation and logistics, export pricing, freight forwarding, shipping and collection documents, payment terms and bank collections, tariffs and duties, packing and marking, marine cargo insurance, and import procedures."
),
(
	640,
	"International Marketing",
	"This course explores similarities and differences of domestic and international marketing programs; sources of information available to firms considering foreign marketing efforts; costs and problems of gathering this information; formulation and implementation of marketing strategies in other environments."
),
(
	641,
	"Entrepreneurship",
	"This course sheds light on the entrepreneurial process, from opportunity recognition to the funding and growth of a new venture. By engaging with case studies and each other, students learn how successful ventures have been created as well as how to create a novel venture from scratch. Importantly, the central aim of this course is not the creation of a successful business per se, but to provide a comprehensive toolkit for prospective founders so that their decision to engage in entrepreneurship is as well thought-out and fruitful as possible."
),
(
	642,
	"Entrepreneurial Strategy",
	"This course provides an in-depth look at the process of building a repeatable and scalable business venture from ideation through achievement of meaningful scale and eventual venture exit. The course focuses on the unique challenges of managing a rapidly growing business. The course is taught as a series of advanced case discussions supplemented with practitioner lectures studying the strategic decisions and day-to-day operational challenges of real start-up companies."
),
(
	643,
	"Strategic Brand Management",
	"This course explores the importance of brands and the process of branding as a vital element of the success of businesses and other organizations. This course is designed to develop student’s ability to build, measure, and manage brand equity through effective and strategic brand promotion. Projects include an audit of a real company’s branding strategy and brand promotion campaigns."
),
(
	644,
	"Retail and Services Management",
	"This course studies the merchandising and management activities of the retailer, as well as retailers’ interactions with distribution intermediaries and manufacturers. Distribution strategies are studied both from the point of view of the manufacturer and retailer."
),
(
	645,
	"Consumer Analysis and Research",
	"This course teaches the student how to measure and analyze consumer attitudes and behavior. Measurement techniques covered include observation, interviews, focus groups, and surveys. Analysis tools used include descriptive statistics, chi square, and spreadsheet analysis for value determination."
);

INSERT INTO Professor_classes (
	Professor_id,
	Class_id,
	Major_id,
	Raw_rating,
	Votes
)
VALUES (
	1,
	1,
	1,
	483,
	100
),
(
	2,
	1,
	1,
	200,
	100
),
(
	3,
	2,
	1,
	246,
	100
),
(
	3,
	3,
	1,
	374,
	100
),
(
	4,
	4,
	1,
	209,
	100
),
(
	2,
	5,
	1,
	450,
	100
),
(
	3,
	6,
	1,
	489,
	100
),
(
	1,
	7,
	1,
	120,
	100
),
(
	2,
	8,
	1,
	327,
	100
),
(
	1,
	9,
	1,
	283,
	100
),
(
	4,
	10,
	1,
	347,
	100
),
(
	5,
	11,
	3,
	287,
	100
),
(
	6,
	11,
	3,
	365,
	100
),
(
	7,
	11,
	3,
	109,
	100
),
(
	8,
	12,
	3,
	89,
	100
),
(
	9,
	12,
	3,
	375,
	100
),
(
	5,
	13,
	3,
	365,
	100
),
(
	8,
	14,
	3,
	498,
	100
),
(
	8,
	15,
	3,
	263,
	100
),
(
	6,
	16,
	3,
	287,
	100
),
(
	11,
	17,
	4,
	30,
	100
),
(
	11,
	18,
	4,
	325,
	100
),
(
	12,
	19,
	4,
	276,
	100
),
(
	13,
	20,
	4,
	345,
	100
),
(
	14,
	20,
	4,
	253,
	100
),
(
	13,
	21,
	4,
	287,
	100
),
(
	13,
	22,
	4,
	187,
	100
),
(
	13,
	23,
	4,
	186,
	100
),
(
	15,
	24,
	5,
	254,
	100
),
(
	18,
	25,
	6,
	232,
	100
),
(
	19,
	26,
	6,
	123,
	100
),
(
	20,
	27,
	6,
	211,
	100
),
(
	19,
	28,
	6,
	321,
	100
),
(
	18,
	29,
	6,
	375,
	100
),
(
	21,
	29,
	6,
	430,
	100
),
(
	18,
	30,
	6,
	213,
	100
),
(
	21,
	31,
	6,
	424,
	100
),
(
	22,
	31,
	6,
	420,
	100
),
(
	23,
	32,
	7,
	276,
	100
),
(
	24,
	32,
	7,
	347,
	100
),
(
	25,
	32,
	7,
	437,
	100
),
(
	24,
	33,
	7,
	397,
	100
),
(
	23,
	34,
	7,
	410,
	100
),
(
	26,
	34,
	7,
	386,
	100
),
(
	25,
	35,
	7,
	254,
	100
),
(
	24,
	36,
	7,
	297,
	100
),
(
	5,
	37,
	8,
	286,
	100
),
(
	27,
	37,
	8,
	187,
	100
),
(
	27,
	38,
	8,
	476,
	100
),
(
	28,
	39,
	8,
	109,
	100
),
(
	18,
	40,
	8,
	34,
	100
),
(
	29,
	41,
	9,
	476,
	100
),
(
	29,
	42,
	9,
	290,
	100
),
(
	30,
	43,
	10,
	487,
	100
),
(
	31,
	43,
	10,
	265,
	100
),
(
	32,
	43,
	10,
	365,
	100
),
(
	38,
	44,
	10,
	209,
	100
),
(
	33,
	44,
	10,
	378,
	100
),
(
	34,
	44,
	10,
	209,
	100
),
(
	22,
	44,
	10,
	187,
	100
),
(
	35,
	45,
	10,
	389,
	100
),
(
	36,
	46,
	10,
	150,
	100
),
(
	37,
	46,
	10,
	289,
	100
),
(
	3,
	632,
	1,
	238,
	100
),
(
	3,
	632,
	5,
	356,
	100
),
(
	8,
	633,
	3,
	321,
	100
),
(
	8,
	633,
	5,
	423,
	100
),
(
	7,
	634,
	3,
	309,
	100
),
(
	7,
	634,
	8,
	289,
	100
),
(
	7,
	635,
	3,
	278,
	100
),
(
	7,
	635,
	8,
	140,
	100
),
(
	10,
	636,
	4,
	285,
	100
),
(
	10,
	636,
	24,
	333,
	100
),
(
	13,
	637,
	4,
	222,
	100
),
(
	13,
	637,
	5,
	111,
	100
),
(
	16,
	638,
	5,
	256,
	100
),
(
	16,
	638,
	6,
	338,
	100
),
(
	16,
	639,
	5,
	399,
	100
),
(
	16,
	639,
	6,
	110,
	100
),
(
	16,
	639,
	7,
	444,
	100
),
(
	15,
	640,
	5,
	475,
	100
),
(
	15,
	640,
	7,
	278,
	100
),
(
	23,
	640,
	5,
	187,
	100
),
(
	23,
	640,
	7,
	327,
	100
),
(
	17,
	641,
	6,
	285,
	100
),
(
	17,
	641,
	24,
	345,
	100
),
(
	10,
	642,
	6,
	99,
	100
),
(
	10,
	642,
	24,
	245,
	100
),
(
	32,
	643,
	6,
	287,
	100
),
(
	32,
	643,
	7,
	336,
	100
),
(
	25,
	644,
	6,
	182,
	100
),
(
	25,
	644,
	7,
	132,
	100
),
(
	25,
	645,
	7,
	372,
	100
),
(
	25,
	645,
	8,
	145,
	100
);
