$(document).ready(function(){

searchprof()

});

function searchprof(){
	$("#btn").click(function(){
		var name = $("#profRating").val();
		console.log($("#profRating").val());
		ajaxsearchprof(name);
	})
}

function ajaxsearchprof(name){
 $.ajax({
        method: "get",
        url: "/search-here?First_name="+name,
        dataType: 'json',
        headers: {
            'Content-Type':'application/json',
            'Access-Control-Allow-Headers':'*',
            'Access-Control-Allow-Origin':'*'
        },
        success: function(data){

        		$("#my-container").empty()

        	 },


        error: function(xhr, status, error) { console.log("ERROR: ", error) }
    
    

    });
};