CREATE TABLE Professors (
	ID int NOT NULL,
	Prefix varchar(10) NOT NULL,
	First_name varchar(100) NOT NULL,
	Last_name varchar(200) NOT NULL,
	Description varchar(1000) NOT NULL,
	URL_img varchar(200) NOT NULL,
	Featured boolean NOT NULL,
	PRIMARY KEY (ID)
);

INSERT INTO Professors (
	ID,
	Prefix,
	First_name,
	Last_name,
	Description,
	URL_img,
	Featured
)
VALUES (
	1,
	"Professor",
	"Sarah",
	"Thorrick",
	"Visiting Assistant Professor of Accounting",
	"prof-pics/sarah-thorrick.jpg",
	"0"
),
(
	2,
	"Dr.",
	"Jean",
	"Meyer",
	"Visiting Assistant Professor of Accounting",
	"prof-pics/jean-meyer.jpg",
	"0"
),
(
	3,
	"Dr.",
	"Daphne",
	"Main",
	"Associate Professor of Accounting",
	"prof-pics/daphne-main.jpg",
	"1"
),
(
	4,
	"Professor",
	"Alfred(Ted)",
	"Stacey",
	"CPA, Visiting Assisstant Professor of Tax Accounting, and Director in the Tax Department of Bourgeois Bennet.",
	"prof-pics/alfred-stacey",
	"0"
),
(
	5,
	"Dr.",
	"Leo",
	"Kras0zhon",
	"Associate Professor of Eco0mics",
	"prof-pics/leo-kras0zhon.jpg",
	"0"
),
(
	6,
	"Dr.",
	"Walter",
	"Block",
	"Harold E. Wirth Eminent Scholar Endowed Chair in Eco0mics",
	"prof-pics/walter-block.jpg",
	"0"
),
(
	7,
	"Dr.",
	"John",
	"Levendis",
	"Associate Dean, Associate Professor of Eco0mics, Dr. John V. Con0r Professor in Eco0mics and Finance.",
	"prof-pics/john-levendis.jpg",
	"1"
),
(
	8,
	"Dr.",
	"William",
	"Barnett II",
	"Chase Distinguished Professor of International Business; Professor of Eco0mics",
	"prof-pics/william-barnett ii.jpg",
	"0"
),
(
	9,
	"Professor",
	"Michael",
	"Spanbauer",
	"Visiting Assisstant Professor of Eco0mics",
	"prof-pics/michael-spanbauer.jpg",
	"0"
),
(
	10,
	"Professor",
	"Jon",
	"Atkinson",
	"Director of the Center for Entrepreneurship and Community Development; Visiting Assistant Professor of Management",
	"prof-pics/jon-atkinson.jpg",
	"1"
),
(
	11,
	"Dr.",
	"Selma",
	"Izadi",
	"Visiting Assistant Professor of Finance",
	"prof-pics/selma-izadi.jpg",
	"0"
),
(
	12,
	"Professor",
	"Michael",
	"Gibbs",
	"CPA, Guest lecturer of Finance, and CFO of MSA Associates, Inc.",
	"NA",
	"0"
),
(
	13,
	"Dr.",
	"Mehmet",
	"Dicle",
	"Stanford H. Rosenthal Professor in Risk, Insurance, and Entrepreneurship; Associate Professor of Finance",
	"prof-pics/mehmet-dicle.jpg",
	"1"
),
(
	14,
	"Professor",
	"Kurt",
	"Gerwitz",
	"Visiting lecturer of Finance",
	"prof-pics/kurt-gerwitz",
	"0"
),
(
	15,
	"Professor",
	"Thomas",
	"McQuaid",
	"Associate Professor in Business",
	"NA",
	"0"
),
(
	16,
	"Professor",
	"Marwan",
	"Kabbani",
	"Lecturer in Business Administration ",
	"NA",
	"0"
),
(
	17,
	"Dr.",
	"Felipe",
	"Massa",
	"Associate Professor of Management",
	"prof-pics/felipe-massa.jpg",
	"0"
),
(
	18,
	"Dr.",
	"Kendra",
	"Reed",
	"Barry and Teresa LeBlanc Professor in Business Ethics; Professor of Management",
	"prof-pics/kendra-reed.jpg",
	"1"
),
(
	19,
	"Professor",
	"Jan",
	"Anderson",
	"Visiting Assistant Professor of Management",
	"prof-pics/jan-anderson.jpg",
	"0"
),
(
	20,
	"Professor",
	"Scott",
	"Sowder",
	"Lecturer in Management",
	"NA",
	"0"
),
(
	21,
	"Professor",
	"Brian",
	"Gueniot",
	"Coordinator/Executive Mentor Program in the College of Business.",
	"prof-pics/brian-gueniot",
	"0"
),
(
	22,
	"Dr.",
	"Michelle",
	"Johnston",
	"Professor of Management",
	"prof-pics/michelle-johnston.jpg",
	"0"
),
(
	23,
	"Dr.",
	"Catherine",
	"Lenihan",
	"Bilingual Marketing and Finance Executive and Professor",
	"prof-pics/catherine-lenihan",
	"0"
),
(
	24,
	"Dr.",
	"Todd",
	"Bacile",
	"Assistant Professor of Marketing; Clifton A. Morvant Distinguished Professor in Business",
	"prof-pics/todd-bacile.jpg",
	"1"
),
(
	25,
	"Dr.",
	"Adam",
	"Mills",
	"Assistant Professor of Marketing",
	"prof-pics/adam-mills.jpg",
	"0"
),
(
	26,
	"Dr.",
	"Sloane",
	"Signal",
	"Visiting Assisstant Professor in Educational Leadership",
	"prof-pics/sloane-signal",
	"0"
),
(
	27,
	"Professor",
	"Nate",
	"Straight",
	"Director of Institutional Effectiveness",
	"prof-pics/nate-straight",
	"0"
),
(
	28,
	"Professor",
	"Aris",
	"Kyriakides",
	"Adjunct Lecturer in Decision Science",
	"prof-pics/aris-kyriakides.jpg",
	"0"
),
(
	29,
	"Professor",
	"Christopher",
	"Screen",
	"Visiting Assistant Professor of Business Law",
	"prof-pics/christopher-screen.jpg",
	"1"
),
(
	30,
	"Professor",
	"Wayne",
	"Del Corral",
	"Visiting Professor of Business Administration",
	"NA",
	"0"
),
(
	31,
	"Professor",
	"Toni",
	"Mobley",
	"Senior Vice President and Chief Services Officer, Audubon Nature Institute",
	"prof-pics/toni-mobley",
	"0"
),
(
	32,
	"Professor",
	"Ashley",
	"Francis",
	"Director of Graduate Programs, Visiting Assistant Professor of Management",
	"prof-pics/ashley-francis.jpg",
	"0"
),
(
	33,
	"Professor",
	"Bradley",
	"Warshauer",
	"Business Writing Specialist",
	"prof-pics/bradley-warshauer",
	"0"
),
(
	34,
	"Dr.",
	"Frankie",
	"Weinberg",
	"Associate Professor of Management",
	"prof-pics/frankie-weinberg.jpg",
	"0"
),
(
	35,
	"Dr.",
	"Nicholas",
	"Capaldi",
	"Legendre-Soulé Distinguished Chair in Business Ethics; Professor of Management",
	"prof-pics/nicholas-capaldi.jpg",
	"1"
),
(
	36,
	"Professor",
	"Harry",
	"Bruns",
	"Guest Instructor and Retired Telecommunications Executive",
	"prof-pics/harry-bruns.jpg",
	"0"
),
(
	37,
	"Dr.",
	"Richard",
	"Peters",
	"Lecturer in Management",
	"prof-pics/richard-peters.jpg",
	"0"
),
(
	38,
	"Dr.",
	"Kathy",
	"Barnett",
	"Director of Portfolio; Internship Program Coordinator; Assistant Professor of Management",
	"prof-pics/kathy-barnett.jpg",
	"1"
);
