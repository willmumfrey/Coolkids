$(document).ready(function(){

getallclass();
getSearchBar();
rateclass();
});



function getallclass(){
 $.ajax({
        method: "get",
        url: "/coolkids-classes",
        dataType: 'json',
        headers: {
            'Content-Type':'application/json',
            'Access-Control-Allow-Headers':'*',
            'Access-Control-Allow-Origin':'*'
        },
        success: function(data){

            var stored = -1;

        for (var i = 0; i<data.length; i++){

            var ratingform = 
            "<option id='class-dropdown' value='class'"+data[i].Class_name+">"                                  
            +data[i].Class_name
            +"-"
            +data[i].First_name+data[i].Last_name
             +"</option>";

            $("#Classes").append(ratingform);
        

            
            

                var a = data[i].Raw_rating;
                var b = data[i].Votes;
                var c = a / b;
                

            // if (stored == data[i].Class_name){
            //     $("#className"+stored).append(data[i].Class_name);                    
            // }
            // else if (stored != data[i].Class_name){
           
            //     stored = data[i].ID;
            

        var classcard = 
            "<div class='class-description'>"

            +"<div class='class-name'>"
            +"<h2 id='className'"+stored+">"
            +data[i].Class_name 
            +"</h2>"
            +"</div>"

            +"<div class='row'>"
            +"<div class='col-sm-2'>"
            +"<div class='row'>"
            +"<div class='classRating'>"
            +"<div class='col-sm-3'>"
            +"<div class='rating-numb'>"
            +c
            +"</div>"
            +"</div>"
            +"<div class='col-sm-12'>"
            +"<div class='rating10'>"
            +"/5"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"<div class='prof-rating'>"
            +"</div>"
            +"</div>"

            +"<div class='col-sm-6'>"
            +"<div class='row'>"
            +"<div class='col-sm-4'>"
            +"<h2>"
            +"Professor:"
            +"</h2>"
            +"</div>"
            +"<div class='col-sm-8'>"
            +"<div class='professor-description'>"
            +"<div class='prof-name'>"
            +"<h1 id='profName'>"
            +"</h1>"
            +"<div class='prof-rating'>"
            +"<h2 id='profRating'>"
            +data[i].Prefix+data[i].First_name+data[i].Last_name
            +"</h2>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"<div class='col-sm-4'>"
            +"<div class='row'>"
            +"<div class='col-sm-6'>"
            +"<h2>"
            +"Credit Hours:"
            +"</h2>"
            +"</div>"
            +"<div class='col-sm-4'>"
            +"<div class='Credits'>"
            +"<h3 id='majorCredits'>"
            +"3"
            +"</h3>"
            +"</div>"
            +"</div>"

            +"</div>"
            +"</div>"
            +"</div>"


            +"<div class='major-class'>"
            +"<div class='row'>"
            +"<div class='col-sm-6'>"
            +"<div class='row'>"
            +"<div class='col-sm-6'>"
            +"<h2>"
            +"School:"
            +"</h2>"
            +"<h3 id='classSchool'>"
            +"College of Business"
            +"</h3>"
            +"</div>"
            +"<div class='col-sm-6'>"
            +"<div class='prof-major'>"
                                                
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"<div class='col-sm-6'>"
            +"<div class='row'>"
            +"<div class='col-sm-6'>"
            +"<h2>"
            +"Major:"
            +"</h2>" 
            +"<div class='col-sm-5'>"
            +"<div class='prof-classes'>"
            +"<h3 id='profMajor'>"
            +data[i].Major_name 
            +"</h3>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"

            +"<h2>"
            +"Class Description:"
            +"</h2>"
            +"<div class='prof-descrip'>"
            +"<p id='classDescrip'>"
            +data[i].Description_class 
            +"</p>"
            +"</div>"
            +"</div>"
            +"</div>";

            $('.class-table').append(classcard);

          

           
        }
        },


            

        
        error: function(xhr, status, error) { console.log("ERROR: ", error) }
    
    

    });
};


var classsearchInput = '';

function getSearchBar(){
    $("#classsearchbar").click(function(){
        var myClassSearchTerm = $("#classsearchInput").val();
        classsearchInput = myClassSearchTerm;
        filterClass();
        console.log(myClassSearchTerm);
    });
           
}

function filterClass(myClassSearchTerm){
    $.ajax({
        method: "GET",
        url: "/class-search-here?myClassSearchTerm=" + classsearchInput,
        dataType: 'json',
        headers: {
            'Content-Type':'application/json',
            'Access-Control-Allow-Headers':'*',
            'Access-Control-Allow-Origin':'*'
        },
        success: function(data){

           $(".class-table").empty();

        var stored = -1;

        for (var i = 0; i<data.length; i++){

                var a = data[i].Raw_rating;
                var b = data[i].Votes;
                var c = a / b;
                

            // if (stored == data[i].Class_name){
            //     $("#className"+stored).append(data[i].Class_name);                    
            // }
            // else if (stored != data[i].Class_name){
           
            //     stored = data[i].ID;
            

        var classcard = 
            "<div class='class-description'>"

            +"<div class='class-name'>"
            +"<h2 id='className'"+stored+">"
            +data[i].Class_name 
            +"</h2>"
            +"</div>"

            +"<div class='row'>"
            +"<div class='col-sm-2'>"
            +"<div class='row'>"
            +"<div class='classRating'>"
            +"<div class='col-sm-3'>"
            +"<div class='rating-numb'>"
            +c
            +"</div>"
            +"</div>"
            +"<div class='col-sm-12'>"
            +"<div class='rating10'>"
            +"/5"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"<div class='prof-rating'>"
            +"</div>"
            +"</div>"

            +"<div class='col-sm-6'>"
            +"<div class='row'>"
            +"<div class='col-sm-4'>"
            +"<h2>"
            +"Professor:"
            +"</h2>"
            +"</div>"
            +"<div class='col-sm-8'>"
            +"<div class='professor-description'>"
            +"<div class='prof-name'>"
            +"<h1 id='profName'>"
            +"</h1>"
            +"<div class='prof-rating'>"
            +"<h2 id='profRating'>"
            +data[i].Prefix+data[i].First_name+data[i].Last_name
            +"</h2>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"<div class='col-sm-4'>"
            +"<div class='row'>"
            +"<div class='col-sm-6'>"
            +"<h2>"
            +"Credit Hours:"
            +"</h2>"
            +"</div>"
            +"<div class='col-sm-4'>"
            +"<div class='Credits'>"
            +"<h3 id='majorCredits'>"
            +"3"
            +"</h3>"
            +"</div>"
            +"</div>"

            +"</div>"
            +"</div>"
            +"</div>"


            +"<div class='major-class'>"
            +"<div class='row'>"
            +"<div class='col-sm-6'>"
            +"<div class='row'>"
            +"<div class='col-sm-6'>"
            +"<h2>"
            +"School:"
            +"</h2>"
            +"<h3 id='classSchool'>"
            +"College of Business"
            +"</h3>"
            +"</div>"
            +"<div class='col-sm-6'>"
            +"<div class='prof-major'>"
                                                
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"<div class='col-sm-6'>"
            +"<div class='row'>"
            +"<div class='col-sm-6'>"
            +"<h2>"
            +"Major:"
            +"</h2>" 
            +"<div class='col-sm-5'>"
            +"<div class='prof-classes'>"
            +"<h3 id='profMajor'>"
            +data[i].Major_name 
            +"</h3>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"

            +"<h2>"
            +"Class Description:"
            +"</h2>"
            +"<div class='prof-descrip'>"
            +"<p id='classDescrip'>"
            +data[i].Description_class 
            +"</p>"
            +"</div>"
            +"</div>"
            +"</div>";

             
          
                $('.class-table').append(classcard);

            // }
        }
        },


            

        
        error: function(xhr, status, error) { console.log("ERROR: ", error) }
    
    

    });
};



var ratingInput = '';
var profidInput = '';
var classidInput= '';


function rateclass(){
    $("#submitrating").click(function(){
        var myratingterm = $("#ratingInput").val();
        ratingInput = myratingterm;
        var myprofidterm = $("#profidInput").val();
        profidInput = myprofidterm;
        var myclassidterm = $("#classidInput").val();
        classidInput = myclassidterm;
        ajaxrateclass();
    });
           
}


function ajaxrateclass(ratingInput,profidInput,classidInput){
 $.ajax({
        method: "post",
        url: "/class-rating?myratingterm="+ratingInput+"&myprofidterm="+profidInput+"&myclassidterm="+classidInput,
        dataType: 'json',
        headers: {
            'Content-Type':'application/json',
            'Access-Control-Allow-Headers':'*',
            'Access-Control-Allow-Origin':'*'
        },
        success: function(data){

            console.log(data);
            // console.log(ratingInput);
            // console.log(profidInput);
            // console.log(classidInput);


        },
        
        error: function(xhr, status, error) { console.log("ERROR: ", error) }
    
    

    });
};