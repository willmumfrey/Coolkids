$(document).ready(function(){

   getallprof();
   getSearchBar();
   
});




function getallprof(){
    console.log("WHAT?")
 $.ajax({
        method: "GET",
        url: "/coolkids-professor_classes",
        dataType: 'json',
        headers: {
            'Content-Type':'application/json',
            'Access-Control-Allow-Headers':'*',
            'Access-Control-Allow-Origin':'*'
        },
        success: function(data){
            
               var stored = -1;
        for (var i = 0; i<data.length; i++){

                // var a = data[i].Raw_rating_sum;
                // var b = data[i].Votes_sum;
                // var c = a/b;
                // console.log(c);
                
            if (data[i].URL_img == "NA"){
                data[i].URL_img = "prof-pics/blank.jpg";
            }
                  
            if (stored == data[i].ID){
             
                $("#profClasses"+stored).append("<ul>"+data[i].Class_name+"</ul>");                    
            }
            else if (stored != data[i].ID){
           
                stored = data[i].ID;
                
            var profcard = 
            "<div class='row'>"
            // +"<div class='col-sm-2'>"
            // +"<div class='row'>"
            // +"<div class='rating-prof'>"
            // +"<div class='col-sm-1'>"
            // +"<div class='rating-numb' style='float:right'>"
            // +c
            // +"</div>"
            // +"</div>"
            // +"<div class='col-sm-1'>"
            // +"<div class='rating10'>"
            // +"/5"
            // +"</div>"
            // +"</div>"
            // +"</div>"
            // +"</div>"
            // +"<div class='prof-rating'>"
            // +"</div>"
            // +"</div>"
            +"<div class='col-sm-5'>"
            +"<div class='headshot'>"
            +"<img src="+data[i].URL_img+">"
            +"</img>"
            +"</div>"
            +"</div>"
            +"<div class='col-sm-7'>"
            +"<div class='professor-description'>"
            +"<div class='prof-name'>"
            +"<h1 id='profName'>"
            +"</h1>"
            +"<div class='prof-rating'>"
            +"<h2 id='profRating'>"
            +data[i].Prefix+data[i].First_name+data[i].Last_name
            +"</h2>"
            +"</div>"
            +"<div class='major-class'>"
            +"<div class='row'>"
            +"<div class='col-sm-6'>"
            +"<div class='row'>"
            +"<div class='col-sm-12'>"
            +"<h2>"
            +"School:"
            +"</h2>"
            +"<h3 id='profSchool'>"
            +"College of Business"
            +"</h3>"
            +"</div>"
            +"<div class='col-sm-6'>"
            +"<div class='prof-major'>"                                   
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"<div class='col-sm-6'>"
            +"<div class='row'>"
            +"<div class='col-sm-12'>"
            +"<h2>"
            +"Major:"
            +"</h2>"                       
            +"<h3 id='profMajor'>"
            + data[i].Major_name 
            +"</h3>"                         
            +"</div>"
            +"</div>"
            +"</div>"
            +"<div class='col-sm-12'>"
            +"<div class='row'>"
            +"<div class='col-sm-12'>"
            +"<h2>"
            +"Classes:"
            +"</h2>"                         
            +"<h4 id='profClasses"
            +stored
            +"'>"
            +"<ul>"
            + data[i].Class_name 
            +"</ul>"
            +"</h4>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
                            
            +"<h2>"
            +"About me"
            +"</h2>"
            +"<div class='prof-descrip'>" 
            + data[i].Description_professor                
            +"<p id='profDescrip' style='background: rgba(223, 153, 0, .5); padding:5px;''>"                 
            +"</p>"
            +"</div>"     
            +"</div>"
            +"</div>"
            +"</div>"     
            +"</div>";

            $(".prof-table").append(profcard);
            }    
    
            }
        },           
        error: function(xhr, status, error) { console.log("ERROR: ", error) }
       });
}


var searchInput = '';

function getSearchBar(){
    $("#searchbar").click(function(){
        var mySearchTerm = $("#searchInput").val();
        searchInput = mySearchTerm;
        filterProf();
        console.log(mySearchTerm);
    });
           
}

function filterProf(mySearchTerm){
    $.ajax({
        method: "GET",
        url: "/search-here?mySearchTerm=" + searchInput,
        dataType: 'json',
        headers: {
            'Content-Type':'application/json',
            'Access-Control-Allow-Headers':'*',
            'Access-Control-Allow-Origin':'*'
        },
        success: function(data){
           
               $(".prof-table").empty();

               var stored = -1;
        for (var i = 0; i<data.length; i++){
              
                
            if (data[i].URL_img == "NA"){
                data[i].URL_img = "prof-pics/blank.jpg";
            }

   

                  
            if (stored == data[i].ID){
                $("#profClasses"+stored).append("<ul>"+data[i].Class_name+"</ul>");                    
            }
            else if (stored != data[i].ID){
           
                stored = data[i].ID;
            var profcard = 
            
            // +"<div class='col-sm-2'>"
            // +"<div class='row'>"
            // +"<div class='rating-prof'>"
            // +"<div class='col-sm-1'>"
            // +"<div class='rating-numb' style='float:right'>"
            // +c
            // +"</div>"
            // +"</div>"
            // +"<div class='col-sm-1'>"
            // +"<div class='rating10'>"
            // +"/5"
            // +"</div>"
            // +"</div>"
            // +"</div>"
            // +"</div>"
            // +"<div class='prof-rating'>"
            // +"</div>"
            // +"</div>"
            +"<div class='col-sm-5'>"
            +"<div class='headshot'>"
            +"<img src="+data[i].URL_img+">"
            +"</img>"
            +"</div>"
            +"</div>"
            +"<div class='col-sm-7'>"
            +"<div class='professor-description'>"
            +"<div class='prof-name'>"
            +"<h1 id='profName'>"
            +"</h1>"
            +"<div class='prof-rating'>"
            +"<h2 id='profRating'>"
            +data[i].Prefix+data[i].First_name+data[i].Last_name
            +"</h2>"
            +"</div>"
            +"<div class='major-class'>"
            +"<div class='row'>"
            +"<div class='col-sm-6'>"
            +"<div class='row'>"
            +"<div class='col-sm-12'>"
            +"<h2>"
            +"School:"
            +"</h2>"
            +"<h3 id='profSchool'>"
            +"College of Business"
            +"</h3>"
            +"</div>"
            +"<div class='col-sm-6'>"
            +"<div class='prof-major'>"                                   
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"<div class='col-sm-6'>"
            +"<div class='row'>"
            +"<div class='col-sm-12'>"
            +"<h2>"
            +"Major:"
            +"</h2>"                       
            +"<h3 id='profMajor'>"
            + data[i].Major_name 
            +"</h3>"                         
            +"</div>"
            +"</div>"
            +"</div>"
            +"<div class='col-sm-12'>"
            +"<div class='row'>"
            +"<div class='col-sm-12'>"
            +"<h2>"
            +"Classes:"
            +"</h2>"                         
            +"<h4 id='profClasses"
            +stored
            +"'>"
            +"<a href='class#className'"+stored+" target='_blank'>"
            + data[i].Class_name 
            +"</a>"
            +"</h4>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
            +"</div>"
                            
            +"<h2>"
            +"About me"
            +"</h2>"
            +"<div class='prof-descrip'>" 
            + data[i].Description_professor                
            +"<p id='profDescrip' style='background: rgba(223, 153, 0, .5); padding:5px;''>"                 
            +"</p>"
            +"</div>"     
            +"</div>"
            +"</div>"
            +"</div>"     
            +"</div>";

  $(".prof-table").append(profcard);
        }
           
     
            }    
    
            
        },
            
        
        error: function(xhr, status, error) { console.log("ERROR: ", error) }
    
    
    });
}; 