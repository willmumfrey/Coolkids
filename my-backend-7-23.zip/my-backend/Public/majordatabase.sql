CREATE TABLE Majors (
	ID int NOT NULL,
	Major_name varchar(100) NOT NULL,
	Description varchar(2000) NOT NULL,
	PRIMARY KEY (ID)
);

INSERT INTO Majors (
	ID,
	Major_name,
	Description
)
VALUES (
	1,
	"Accounting",
	"Accounting or accountancy is the measurement, processing, and communication of financial information about economic entities such as businesses and corporations. "
	),
(
	3,
	"Economics",
	"Economics is the social science that studies the production, distribution, and consumption of goods and services."
),
(
	4,
	"Finance",
	"Finance is a field that is concerned with the allocation (investment) of assets and liabilities (known as elements of the balance statement) over space and time, often under conditions of risk or uncertainty. Finance can also be defined as the science of money management."
),
(
	5,
	"International Business",
	"International business refers to the trade of goods, services, technology, capital and/or knowledge at a global level. It involves cross-border transactions of goods and services between two or more countries. Transactions of economic resources include capital, skills, and people for the purpose of the international production of physical goods and services such as finance, banking, insurance, and construction. International business is also known as globalization."
),
(
	6,
	"Management",
	"Management (or managing) is the administration of an organization, whether it is a business, a not-for-profit organization, or government body. Management includes the activities of setting the strategy of an organization and coordinating the efforts of its employees (or of volunteers) to accomplish its objectives through the application of available resources, such as financial, natural, technological, and human resources."
),
(
	7,
	"Marketing",
	"Marketing is the study and management of exchange relationships. Marketing is used to create, keep and satisfy the customer. With the customer as the focus of its activities, it can be concluded that Marketing is one of the premier components of Business Management - the other being innovation."
),
(
	8,
	"Decision Science",
	"Decision Science (or Decision Theory) is the study of the reasoning underlying an agents choices."
),
(
	9,
	"Legal Studies",
	"Legal Studies or Jurisprudence is the theoretical study of law, principally by philosophers but, from the twentieth century, also by social scientists. Scholars of jurisprudence, also known as jurists or legal theorists, hope to obtain a deeper understanding of legal reasoning, legal systems, legal institutions, and the role of law in society."
),
(
	10,
	"Business Administration",
	"Business administration is management of a business. It includes all aspects of overseeing and supervising business operations and related fields which include accounting, finance and marketing."
),
(
	24,
	"Entrepreneurship",
	"Entrepreneurship is the process of designing, launching and running a new business, which is often initially a small business. The people who create these businesses are called entrepreneurs."
);