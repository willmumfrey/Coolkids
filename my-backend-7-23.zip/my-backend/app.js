

const express = require('express')
var mysql = require('mysql');
const app = express()

var bodyParser = require('body-parser');


var pool = mysql.createPool({
	host	:'localhost',
	user	:'root',
	password:'root',
	database:'coolkids'
});
app.use(bodyParser.urlencoded({limit: '50mb',extended: true}));
app.use(bodyParser.json({limit: '50mb'}));

var path = require('path');

app.use(express.static(__dirname + '/Public')); // set the static files location /public/img will be /img for users


//Frontend route

app.get('/', function(req, res) {

   res.sendFile(path.resolve('Public/html.html'));
 
 })

app.get('/profs', function(req, res) {

   res.sendFile(path.resolve('Public/prof-table.html'));
 
 })

app.get('/class', function(req, res) {

   res.sendFile(path.resolve('Public/class-table.html'));

 })

app.get('/rating', function(req, res) {

   res.sendFile(path.resolve('Public/rating-table.html'));

 })

 app.post('/class', function(req, res) {

   req.sendFile(path.resolve('Public/class-table.html'));
 })

///////////////////////////////////////////////////////




app.get('/coolkids-professor_classes', function(req,res){
	
	pool.getConnection(function(err,connection){
		//Use the connection
		connection.query('Select Professors.ID, Professors.URL_img, Professors.Prefix,Professors.First_name,Professors.Last_name,Professors.Description_professor,Classes.Class_name,Majors.Major_name,Raw_rating,Votes From Professor_classes Inner Join Professors On Professor_id=Professors.ID Inner Join Majors On Major_id=Majors.ID Inner Join Classes On Class_id=Classes.ID;', function(error,results,fields){

			connection.release();

			if(!err){

				res.json(results);

			}

		});


	});

});

app.get('/coolkids-classes', function(req,res){
	
	pool.getConnection(function(err,connection){
		//Use the connection
		connection.query('Select Professors.ID AS Professor_id,Classes.ID AS Class_id,Professors.Prefix,Professors.First_name,Professors.Last_name,Classes.Class_name,Classes.Description_class,Majors.Major_name,Raw_rating,Votes From Professor_classes Inner Join Professors On Professor_id=Professors.ID Inner Join Majors On Major_id=Majors.ID Inner Join Classes On Class_id=Classes.ID;', function(error,results,fields){

			connection.release();

			if(!err){

				res.json(results);

			}

		});


	});

});


app.get('/search-here', function(req, res){
    pool.getConnection(function(err, connection){
    	var searchTerm = req.query.mySearchTerm;
    		console.log(searchTerm);
    
    	var sqlQuery = "Select Professors.ID, Professors.URL_img, Professors.Prefix,Professors.First_name,Professors.Last_name,Professors.Description_professor,Classes.Class_name,Majors.Major_name,Raw_rating,Votes From Professor_classes Inner Join Professors On Professor_id=Professors.ID Inner Join Majors On Major_id=Majors.ID Inner Join Classes On Class_id=Classes.ID WHERE Professors.First_name LIKE'"+searchTerm+"%' OR Professors.Last_name LIKE'"+searchTerm+"%'";
    	console.log(sqlQuery);

        connection.query(sqlQuery, function(error,results,fields){
		
			

			if(!err){

				res.json(results);

			}

		});


	});

});


app.get('/class-search-here', function(req, res){
    pool.getConnection(function(err, connection){
    	var classsearchTerm = req.query.myClassSearchTerm;
    		console.log(classsearchTerm);
    
    	var sqlQueryclass = "Select Professors.ID, Professors.Prefix,Professors.First_name,Professors.Last_name,Classes.Class_name,Classes.Description_class,Majors.Major_name,Raw_rating,Votes From Professor_classes Inner Join Professors On Professor_id=Professors.ID Inner Join Majors On Major_id=Majors.ID Inner Join Classes On Class_id=Classes.ID WHERE Classes.Class_name LIKE'%"+classsearchTerm+"%' OR Majors.Major_name LIKE'"+classsearchTerm+"%'";
    	console.log(sqlQueryclass);

        connection.query(sqlQueryclass, function(error,results,fields){
		
			

			if(!err){

				res.json(results);

			}

		});


	});

})




app.get('/rating-high', function(req, res){
    pool.getConnection(function(err, connection){
    	// var classsearchTerm = req.query.myClassSearchTerm;
    	// 	console.log(classsearchTerm);
    
    	var sqlQueryclass = "Select Professors.ID, Professors.Prefix,Professors.First_name,Professors.Last_name,Classes.Class_name,Classes.Description_class,Majors.Major_name,Raw_rating,Votes, (Raw_rating / Votes) AS Rating From Professor_classes Inner Join Professors On Professor_id=Professors.ID Inner Join Majors On Major_id=Majors.ID Inner Join Classes On Class_id=Classes.ID Order by Rating DESC;";
    	console.log(sqlQueryclass);

        connection.query(sqlQueryclass, function(error,results,fields){
		
			

			if(!err){

				res.json(results);

			}

		});


	});

})

app.get('/rating-low', function(req, res){
    pool.getConnection(function(err, connection){
    	// var classsearchTerm = req.query.myClassSearchTerm;
    	// 	console.log(classsearchTerm);
    
    	var sqlQueryclass = "Select Professors.ID, Professors.Prefix,Professors.First_name,Professors.Last_name,Classes.Class_name,Classes.Description_class,Majors.Major_name,Raw_rating,Votes, (Raw_rating / Votes) AS Rating From Professor_classes Inner Join Professors On Professor_id=Professors.ID Inner Join Majors On Major_id=Majors.ID Inner Join Classes On Class_id=Classes.ID Order by Rating ASC;";
    	console.log(sqlQueryclass);

        connection.query(sqlQueryclass, function(error,results,fields){
		
			

			if(!err){

				res.json(results);

			}

		});


	});

})

app.post('/class-rating', function(req, res){
	 	var ratingterm = req.body.myratingterm;
    		console.log(ratingterm);
    	var profidterm = req.body.myprofidterm;
    		console.log(profidterm);
    	var classidterm = req.body.myclassidterm;
    		console.log(classidterm);
    pool.getConnection(function(err, connection){
    
    	var sqlQueryrating = "UPDATE Professor_classes SET Raw_rating= Raw_rating+"+ratingterm+", Votes= Votes+5 WHERE Professor_id="+profidterm+" AND Class_id="+classidterm;
    	console.log(sqlQueryrating);

        connection.query(sqlQueryrating, function(error,results,fields){
		
			

			if(!err){

				res.json(results);

			}

		});


	});

})

app.post('/wills-second-route', function(req,res){
	console.log('hello world');
	res.send('hello world - this is the response');
});

// turn computer into server
app.listen(3000, () => console.log('Example app listening on port 3000!'))
